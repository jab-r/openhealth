/**
 *
 * Copyright 2000-2001 Jonathan Borden
 *
 * Licensed for use and modification according to
 * http://www.openhealth.org/license/
 *
 * XMTPReader - an XMLReader for MIME
 *
 */
package org.openhealth.xmtp;

import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Properties;

import javax.mail.*;
import javax.mail.internet.*;

import org.xml.sax.*;
import org.xml.sax.helpers.*;

import java.io.*;

/** XMTPReader is an XMLReader for RFC 822/MIME documents
 * XMTP implements SAX grove parsing of MIME messages
 * @author <a href="mailto:jonathan@openhealth.org">Jonathan Borden</a>
 *
 */

public class XMTPReader implements XMLReader {
    static final String rdfNS = "http://www.w3.org/1999/02/22-rdf-syntax-ns#";
    static final String mimeNS = "http://www.openhealth.org/xmtp";
    static final String mimeNSrdf = "http://www.openhealth.org/xmtp#";
    
    static Attributes emptyAtts;
    static AttributesImpl headerAtts;
    static boolean debug = false;
    static {
        emptyAtts = new AttributesImpl();
        headerAtts = new AttributesImpl();
        headerAtts.addAttribute(rdfNS,"parseType","web:parseType","CDATA","Resource");
    }
    static final char[] crlf = {' '};
    Properties props = null;
    ContentHandler contentHandler = null;
    DTDHandler dtdHandler = null;
    ErrorHandler errorHandler = null;
    EntityResolver entityResolver = null;
    boolean asRDF = true;
    
/** Construct an XMTPReader
 *
 * @param ch A SAX <i>ContentHandler</i>
 *
 */
    
    public XMTPReader(ContentHandler ch) {
        contentHandler = ch;
    }
    
    public XMTPReader() {
        contentHandler = null;
    }
    
/** Parse an InputSource
 * @param insrc the InputSource to parse
 * @throws IOException
 * @throws SAXException
 */    
    public void parse(InputSource insrc)
    throws IOException, SAXException
    {
        try{
            Session session = Session.getDefaultInstance((props == null) ? System.getProperties() : props);
            InputStream is = insrc.getByteStream();
            MimeMessage msg = new MimeMessage(session,is);
            String aboutURI = msg.getMessageID();
            boolean isMid = (aboutURI != null);
            if (aboutURI == null)
                aboutURI = msg.getContentID();
            if ((aboutURI != null) && (aboutURI.charAt(0)=='<'))
            {
                int iclose = aboutURI.indexOf('>');
                aboutURI = aboutURI.substring(1,iclose);
            };
            if (aboutURI != null)
                aboutURI = ((isMid) ? "mid:" : "cid:" )+aboutURI;
                contentHandler.startDocument();
                processMessage((MimePart)msg,aboutURI);
                contentHandler.endDocument();
        } catch (MessagingException e) {
            throw new SAXException(e);
        }
    }
    
/** parse a system id
 * @param systemId The System Id to parse
 * @throws IOExceptionan
 * @throws SAXException
 */    
    public void parse(String systemId)
    throws IOException, SAXException
    {
        parse((entityResolver==null) ? new InputSource(systemId) : entityResolver.resolveEntity("",systemId));
    }
    
    boolean processMessage(MimePart msgPart, String aboutURI)
    throws MessagingException,SAXException,IOException
    {
        
        String mimeNS = (asRDF) ? XMTPReader.mimeNSrdf : XMTPReader.mimeNS;
        AttributesImpl msgAtts = new AttributesImpl();
        if (asRDF) {
            if (aboutURI == null) {
                String[] mid = msgPart.getHeader("Message-ID");
                if ((mid != null)&& ( mid.length > 0)) {
                    aboutURI = mid[0];
                };
            };
            contentHandler.startPrefixMapping("web",rdfNS);
            if (aboutURI != null)
                msgAtts.addAttribute(rdfNS, "about", "web:about", "CDATA",aboutURI);
            if (debug && (aboutURI != null)) System.out.println(aboutURI);
        }
        
        contentHandler.startPrefixMapping("",mimeNS);
        contentHandler.startPrefixMapping("mime",mimeNS);
        
        contentHandler.startElement(mimeNS, "Message", "Message",msgAtts);
        
        // handle headers
        
        for (Enumeration enum = msgPart.getAllHeaders(); enum.hasMoreElements(); )
        {
            Header header = (Header) enum.nextElement();
            String name = header.getName();
            
            String hdrVal = header.getValue();
            XMTPHeader xhdr = null;
            int nparam = 0;
            int psep = hdrVal.indexOf(';');
            
            if (psep >= 0) {
                xhdr = new XMTPHeader(name,hdrVal);
                nparam = xhdr.getParamCount();
            }
            String value = (nparam == 0) ? hdrVal : xhdr.getValue();
            if (value == null) {
                nparam = 0;
                value = hdrVal;
                if (debug) System.out.println("null value: np = "+nparam+" header:"+hdrVal);
            };
            
            if (nparam == 0) {
                contentHandler.startElement(mimeNS,name,name,emptyAtts);
                contentHandler.characters(hdrVal.toCharArray(),0,hdrVal.length());
                contentHandler.endElement(mimeNS,name,name);
            }
            else
            {
                AttributesImpl atts = new AttributesImpl();
                Hashtable params = xhdr.getParameters();
                if (asRDF)
                    contentHandler.startElement(mimeNS,name,name,headerAtts);
                for(Enumeration eparam = params.keys(); eparam.hasMoreElements();) {
                    String key = (String) eparam.nextElement();
                    if (asRDF)
                    {
                        contentHandler.startElement(mimeNS,key,key,emptyAtts);
                        String pval = (String) params.get(key);
                        contentHandler.characters(pval.toCharArray(),0,pval.length());
                        contentHandler.endElement(mimeNS,key,key);
                    }
                    else
                    {
                        atts.addAttribute("",key,key,"CDATA",(String)params.get(key));
                    }
                    if (debug) System.out.println("param: "+key+" value: "+(String)params.get(key));
                };
                if (!asRDF)
                    contentHandler.startElement(mimeNS,name,name,atts);
                
                if (asRDF)
                    contentHandler.startElement(rdfNS,"value","web:value",emptyAtts);
                contentHandler.characters(value.toCharArray(),0,value.length());
                if (asRDF) contentHandler.endElement(rdfNS,"value","web:value");
                contentHandler.endElement(mimeNS,name,name);
            };
        };
        
        // handle body -- is it single or multipart?
        Object body = msgPart.getContent();
        contentHandler.startPrefixMapping("","");

        contentHandler.startElement(mimeNS,"Body","mime:Body",emptyAtts);
        if (body instanceof MimeMultipart)
        {
            MimeMultipart mmp = (MimeMultipart) body;
            if (debug) System.out.println("--multipart message-- "+mmp.getCount());
            for(int i=0;i<mmp.getCount();i++) {
                MimeBodyPart bp = (MimeBodyPart) mmp.getBodyPart(i);
                String cid = bp.getContentID();
                processMessage(bp,cid);
            };
        } else if (body instanceof String) {
            if (debug) System.out.println("--string message-- "+msgPart.getContentType());
            String txt = (String)body;
            contentHandler.characters(txt.toCharArray(),0,txt.length());
        } else {
            InputStream is = (InputStream) body;
            String ct = msgPart.getContentType();
            if (debug) System.out.println("--other message-- "+ct+" "+body.getClass().getName());
            if (ct.endsWith("/xml") || ct.endsWith("+xml")) {
                
                XMLReader reader = XMLReaderFactory.createXMLReader();
                reader.setContentHandler(contentHandler);
                reader.setEntityResolver(entityResolver);
                reader.setErrorHandler(errorHandler);
                reader.setDTDHandler(dtdHandler);
                reader.parse(new InputSource(is));
            } else {
                /*String encoding = msgPart.getEncoding();
                if (encoding.equals("binary")) {*/
                    byte[] raw = new byte[2048];
                    int ir = 0;
                    do
                    {
                        ir = is.read(raw);
                        char[] res = Base64.encode(raw,ir);
                        contentHandler.characters(res,0,res.length);
                    }
                    while (ir > 0);
                /*} else {
                    InputStream rawis = msgPart.getDataHandler().getInputStream();
                    if (debug) System.out.println("input stream class="+rawis.getClass().getName());
                    InputStreamReader isr = new InputStreamReader(rawis);
                    char[] buf = new char[2048];
                    int nr;
                    while (0 < (nr = isr.read(buf,0,2048)) )
                        contentHandler.characters(buf,0,nr);
                }*/
            };
        };
        
        contentHandler.endElement(mimeNS,"Body","mime:Body");
        contentHandler.endPrefixMapping("");
        contentHandler.endElement(mimeNS, "Message","Message");
        contentHandler.endPrefixMapping("");
        contentHandler.endPrefixMapping("mime");
        if (asRDF) contentHandler.endPrefixMapping("web");
        return true;
    }
    
    public ContentHandler getContentHandler()
    {
        return contentHandler;
    }
    
    public void setContentHandler(ContentHandler ch)
    {
        contentHandler = ch;
    }
    
    public DTDHandler getDTDHandler()
    {
        return dtdHandler;
    }
    
    public void setDTDHandler(DTDHandler dh)
    {
        dtdHandler = dh;
    }
    
    public EntityResolver getEntityResolver()
    {
        return entityResolver;
    }
    
    public void setEntityResolver(EntityResolver er)
    {
        entityResolver = er;
    }
    
    public ErrorHandler getErrorHandler()
    {
        return errorHandler;
    }
    
    public void setErrorHandler(ErrorHandler eh)
    {
        errorHandler = eh;
    }
    
/** see <a href="#setFeature">setFeature</a>
 * @param feature
 * @throws SAXNotRecognizedException
 * @throws SAXNotSupportedException
 * @return
 */    
    public boolean getFeature(String feature)
    throws SAXNotRecognizedException,SAXNotSupportedException
    {
        if (feature.equals("http://www.openhealth.org/xmtp/features/parse-as-rdf-1.0"))
        {
            return asRDF;
        }
        else if (feature.equals("http://xml.org/sax/features/namespaces"))
        {
            return true;
        }
        else if (feature.equals("http://xml.org/sax/features/namespace-prefixes"))
        {
            return false;
        }
        throw new SAXNotRecognizedException(feature);
    }
    
    public Object getProperty(String prop)
    throws SAXNotRecognizedException,SAXNotSupportedException
    {
        throw new SAXNotRecognizedException(prop);
    }
    
/** sets parser features
 * @param feature <p>The feature: <code>http://www.openhealth.org/xmtp/features/parse-as-rdf-1.0</code> implements XMTP 2.0 parsing as an RDF 1.0 compatible SAX stream
 * </p>
 * @param b <p><i>true:</i> parse as RDF 1.0/XMTP 2.0</p>
 * <p><i>false:</i> parse as XMTP 1.0</p>
 * @throws SAXNotRecognizedException
 * @throws SAXNotSupportedException
 */    
    public void setFeature(String feature,boolean b)
    throws SAXNotRecognizedException,SAXNotSupportedException
    {
        if (feature.equals("http://www.openhealth.org/xmtp/features/parse-as-rdf-1.0"))
        {
            asRDF = b;
        }
        else if (feature.equals("http://xml.org/sax/features/namespaces") && !b)
        {
            throw new SAXNotSupportedException(feature); // always support namespaces
        }
        else if (feature.equals("http://xml.org/sax/features/namespace-prefixes") && b)
        {
            throw new SAXNotSupportedException(feature); // never report ns prefixes as attributes
        }
        throw new SAXNotRecognizedException(feature);
    }
    public void setProperty(String prop,Object obj)
    throws SAXNotRecognizedException,SAXNotSupportedException
    {
        throw new SAXNotRecognizedException(prop);
    }
    static public void setDebug(boolean b) {
        debug = b;
    }
}

