/**
 *
 * Copyright 2000-2001 Jonathan Borden
 *
 * Licensed for use and modification according to
 * http://www.openhealth.org/license/
 *
 * XMTPHeader.java
 *
 */
package org.openhealth.xmtp;

import java.util.Enumeration;
import java.util.Hashtable;

import javax.mail.Part;

import javax.mail.internet.HeaderTokenizer;
import javax.mail.internet.HeaderTokenizer.Token;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.ParseException;

import org.xml.sax.*;
import org.xml.sax.helpers.AttributesImpl;

/** Helper class to process RFC 822 headers
 * @author <a href="mailto:jonathan@openhealth.org">Jonathan Borden</a>
 */
public class XMTPHeader
{
/** Constructor
 * @param name The name of the header
 * @param header The rest of the header line following name
 * @throws ParseException an exception thrown during parsing of RFC 822
 * @throws SAXException an exception throw parsing XML content
 */    
    public XMTPHeader( String name, String header)
    throws ParseException,SAXException
    {
        _value = null;
        _params = new Hashtable(5); // max number of MIME parameters
        _name = name;
        //String mimeNS = (where == null) ? XMTPReader.mimeNS : XMTPReader.mimeNSrdf;
        // parse the header line looking for the MIME specifics
        if ( header == null )
        {
            _value = new String( "<<default>>" );
        }
        
        String xname = null;
        String xvalue = null;
        HeaderTokenizer.Token xtoken;
        
        HeaderTokenizer tokenizer = new HeaderTokenizer( header, HeaderTokenizer.RFC822+"=",true );//MIME
        
        do {
            xtoken = tokenizer.next();
            switch ( xtoken.getType() ){

                case ';': // end of a parameter
                    if ( _value == null )
                    {
                        if ( xname == null || xvalue != null )
                        {
                            _nparams = 0;
                            _value = header;
                            return; // skip for now
                            //throw new ParseException( "Syntax error parsing parameter: no name:"+xvalue);
                        }
                        
                        _value = xname;
                    }
                    else if ( xname == null || xvalue == null )
                    {
                        throw new ParseException( "Syntax error parsing parameter: no name or value" );
                    }
                    else
                    {
                        _params.put( xname, xvalue );
                        _nparams++;
                    }
                    
                    // reset for next parameter
                    xname = null;
                    xvalue = null;
                    break;
                    
                case '=':
                    if ( xname == null || xvalue != null )
                    {
                        throw new ParseException( "Syntax error parsing parameter value" );
                    }
                    break;
                    
                case HeaderTokenizer.Token.QUOTEDSTRING:
                    /*xtoken =
                    new HeaderTokenizer.Token( HeaderTokenizer.Token.ATOM,'"'+xtoken.getValue()+'"');
                    */
                case HeaderTokenizer.Token.ATOM:
                    if ( xname == null )
                    {
                        xname = xtoken.getValue();
                    }
                    else if ( xvalue == null )
                    {
                        xvalue = xtoken.getValue();
                    }
                    else
                    {
                        xvalue = xvalue + xtoken.getValue();
                    }
                    break;
                    
                case HeaderTokenizer.Token.COMMENT:
                    break;
                    
                case HeaderTokenizer.Token.EOF:
                    if ( xname != null )
                    {
                        if ( xvalue != null )
                        {
                            // parameter name and value pair
                            _params.put( xname, xvalue );
                            _nparams++;
                        }
                        else
                        {
                            // value
                            if ( _value != null )
                            {
                                throw new ParseException
                                ( "Syntax error: Duplicate header value" );
                            }
                            _value = xname;
                        }
                    }
                    break;
            }
        } while ( xtoken.getType() != HeaderTokenizer.Token.EOF );
        
        // last check to make sure that at lease type was specific
        if ( _value == null )
        {
            throw new ParseException( "Syntax error: missing header value" );
        }
    }
    
/** <p>Header value</p>
 * <p>Content-Type: multipart/alternative; boundary="foo"</p>
 * <p>the value = "multipart/alternative"</p>
 * @return the value of the header
 */    
    public String getValue()
    {
        return _value;
    }
    
    public boolean match( String value )
    {
        return _value.equals( value );
    }
    
/** Gets the value of a parameter
 * @param name parameter name
 * @return parameter value
 */    
    public String getParameter( String name )
    {
        return (String)_params.get( name );
    }
       
    public String getValues()
    {
        String s822 = _value + ';';
        for ( Enumeration en = _params.keys() ; en.hasMoreElements() ; )
        {
            String xname = (String)en.nextElement();
            String xvalue = (String)_params.get( xname );
            s822 = s822 + xname + '=' + xvalue + ';';
        }
        
        return s822;
    }
/** A Hashtable of &lt;param,value&gt;
 * @return the parsed params
 */    
    public Hashtable getParameters()
    {
        return _params;
    }
    public String toString()
    {
        return _name + getValues();
    }
/** Count of parameters in header
 * @return number of parameters in header
 */    
    public int getParamCount()
    {
        return _nparams;
    }
    String 	_name;
    int _nparams = 0;
    String	_value;
    Hashtable	_params;
    static final Attributes emptyAtts = new AttributesImpl();
}

