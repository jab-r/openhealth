/*
 * TestXMTP.java
 *
 * Created on April 22, 2001, 7:55 PM
 */
import org.openhealth.xmtp.*;
import com.megginson.sax.*;
import org.xml.sax.helpers.*;
import org.xml.sax.*;
import java.io.*;
/**
 *
 * @author  <a href="mailto:jonathan@openhealth.org">Jonathan Borden</a>
 * @version 
 */
public class TestXMTP extends java.lang.Object {

    /** Creates new TestXMTP */
    public TestXMTP() {
    }

    /**
    * @param args the command line arguments
    */
    public static void main (String args[]) {
        try{
        String sysId = args[0];
        System.out.println("input="+sysId);
        XMLWriter wr;
        if (args.length > 1) {
            String outFile = args[1];
            wr = new XMLWriter(new FileWriter(outFile));
        } else
            wr = new XMLWriter();
        
        XMTPReader reader = new XMTPReader((ContentHandler)wr);
        reader.setDebug(true);
        InputSource src = new InputSource(new FileInputStream(sysId));
        src.setSystemId(sysId);
        reader.parse(src);
        } catch (Exception e) {
              e.printStackTrace(System.out);
        };
    }

}
