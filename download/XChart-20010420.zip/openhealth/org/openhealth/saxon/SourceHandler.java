package org.openhealth.saxon;
import org.xml.sax.ContentHandler;
import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import org.xml.sax.*;
import com.megginson.sax.XMLWriter;

public interface SourceHandler {
	public void init(ServletConfig config) throws ServletException;
	public XMLWriter getXMLWriter(AbstractSaxonServlet servlet,String txnID,String txnState,String loc,String uid,HttpServletRequest req,HttpServletResponse res)
				throws SAXException,IOException,FileNotFoundException;
	public void reset(HttpServletRequest req, HttpServletResponse res) throws Exception;
};