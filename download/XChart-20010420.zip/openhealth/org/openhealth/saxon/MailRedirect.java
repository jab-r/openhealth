package org.openhealth.saxon;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;

import com.icl.saxon.*;
import com.icl.saxon.output.*;
import com.icl.saxon.expr.*;
import org.xml.sax.*;
import org.xml.sax.helpers.*;
import com.icl.saxon.trax.*;
import com.icl.saxon.trax.serialize.*;

import javax.mail.*;
import javax.mail.internet.*;

import org.openhealth.mail.SmartTransport;

import org.openhealth.sax.*;


public class MailRedirect implements ResponseHandler {
	String user;
	String where;
	InternetAddress[] to;
	boolean multipart = false;
	public void init(ServletConfig config) throws ServletException {
		try{
		user = config.getInitParameter("default-user");
		if (user == null)
			user = "user@openhealth.org";
		where = config.getInitParameter("remote-signed");
		if (where == null)
			where = "billing@openhealth.org";
		System.err.println("[init] SignOpnote user= "+user+" where= "+where);
		to = InternetAddress.parse(where,false);
		} catch (Exception e) {
			e.printStackTrace(System.err);
			throw new ServletException(e);
		};
	};

	public void handle(AbstractSaxonServlet servlet,ByteArrayOutputStream baos,HttpServletRequest req,HttpServletResponse res,String uid2, String contentType)
		throws Exception
{
	try{
		Session session = Session.getDefaultInstance(System.getProperties(),null);
		//ByteArrayInputStream bais = new ByteArrayInputStream(baos.toByteArray());
		MimeMessage msg = new MimeMessage(session/*,bais*/);
		//msg.setHeader("Content-Type","text/html");
		msg.setFrom(new InternetAddress(user));
		//InternetAddress[] to = InternetAddress.parse(where, false);
	    msg.setRecipients(Message.RecipientType.TO,to);
		msg.setSubject("opnote");
		msg.setSentDate(new Date());

		if (contentType.equals("text/html")) {
			MimeBodyPart mimeBodyPart = new MimeBodyPart ();
			String htmlString = baos.toString();
			mimeBodyPart.setContent (htmlString, contentType);
			MimeBodyPart textPart = new MimeBodyPart();
			StringWriter textWriter = new StringWriter();
			StringReader htmlReader = new StringReader(htmlString);
			/*
				strip all markup
			*/
			int c = 0;
			int mark = 0;
			while(-1 != (c = htmlReader.read())) {
				if (c == '<')
					mark++;
				if (mark == 0)
					textWriter.write(c);
				if (c == '<')
					mark--;
			};

			textPart.setText(textWriter.toString());

			Multipart multiPart = new MimeMultipart ("alternative");
			multiPart.addBodyPart(textPart);
			multiPart.addBodyPart(mimeBodyPart);

			msg.setContent (multiPart);

		} else {
			msg.setText(baos.toString());
			msg.setHeader("Content-Type",contentType);
		};
		msg.saveChanges();
   
		SmartTransport transport = new SmartTransport();

		transport.sendMessage(msg,to);


		baos.close();

		baos = null;

		} catch (Exception ee) {
			System.err.println("exception caught attemping to e-mail opnote");
			ee.printStackTrace(System.err);
			throw ee;
		};
	};
};