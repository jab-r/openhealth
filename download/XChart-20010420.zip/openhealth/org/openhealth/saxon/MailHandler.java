package org.openhealth.saxon;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;

import com.icl.saxon.*;
import com.icl.saxon.output.*;
import com.icl.saxon.expr.*;
import org.xml.sax.*;
import org.xml.sax.helpers.*;
import com.icl.saxon.trax.*;
import com.icl.saxon.trax.serialize.*;

import javax.mail.*;
import javax.mail.internet.*;

//import org.apache.james.*;
import org.openhealth.mail.SmartTransport;
import org.openhealth.sax.*;


public class MailHandler implements org.openhealth.saxon.SourceHandler {
		ByteArrayOutputStream baos;
		FileOutputStream fos;
		public void init(ServletConfig config) throws ServletException {};
	public ContentHandler getContentHandler(org.openhealth.saxon.AbstractSaxonServlet servlet,ContentHandler chIn,String txnID,String txnState,String loc,String uid,HttpServletRequest req,HttpServletResponse res) 
		throws SAXException,IOException,FileNotFoundException
	{
		XMLEmitter emit = new XMLEmitter();
		EmitterFilter emitFilter = new EmitterFilter(emit);
		//Serializer serForm = SerializerFactory.getSerializer(Method.XML);
		//out.println("<p>got serializer</p>");

		OutputDetails details1;
		 fos = new FileOutputStream(servlet.getRepositoryFile(req,loc,uid));
		 baos = new ByteArrayOutputStream();
		 details1 = new OutputDetails();
		 details1.setMethod("html");
		 emit.setWriter(new PrintWriter(baos));
		 emit.setOutputDetails(details1);

		return (ContentHandler) new Fork2Impl(chIn,(ContentHandler)emitFilter);
	};
	public void reset(HttpServletRequest req, HttpServletResponse res) throws Exception {
		try{
		baos.writeTo(fos);
		Session session = Session.getDefaultInstance(System.getProperties(),null);
		//ByteArrayInputStream bais = new ByteArrayInputStream(baos.toByteArray());
		MimeMessage msg = new MimeMessage(session/*,bais*/);
		//msg.setHeader("Content-Type","text/html");
		msg.setFrom(new InternetAddress("user@openhealth.org"));
		InternetAddress[] to = InternetAddress.parse("jonathan@openhealth.org", false);
	    msg.setRecipients(Message.RecipientType.TO,to);
		msg.setSubject("opnote");
		msg.setSentDate(new Date());
		msg.saveChanges();


		MimeBodyPart mimeBodyPart = new MimeBodyPart ();
		mimeBodyPart.setContent (baos.toString(), "text/html");

		Multipart multiPart = new MimeMultipart ();
		multiPart.addBodyPart (mimeBodyPart);

		msg.setContent (multiPart);

   
		SmartTransport transport = new SmartTransport();

		transport.sendMessage(msg,to);
		try{
			fos.close();
		} catch(IOException e) {};
		try{
			baos.close();
		} catch(IOException e) {};
		baos = null;
		fos = null;
		} catch (Exception ee) {
			System.err.println("exception caught attemping to e-mail opnote");
			ee.printStackTrace(System.err);
			throw ee;
		};
	};
};