package org.openhealth.saxon;
/*
 * <p>Copyright (c) 2000-2001 The Open Healthcare Group</p>
 * <p>Licensed for distribution and/or use according to the Open Health Community License
 * see <a href="http://www.openhealth.org/license/">http://www.openhealth.org/license/</a>
 * <br />
 * <i>This software comes with NO WARRANTY or guarantee of fitness for any purpose.</i></p>
 */

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;

import org.xml.sax.*;
import org.xml.sax.helpers.*;

import org.openhealth.sax.*;


public interface ResponseHandler {
	public void init(ServletConfig config) throws ServletException;
	public void handle(AbstractSaxonServlet servlet,ByteArrayOutputStream baos,HttpServletRequest req,HttpServletResponse res,String uid2, String contentType)
		throws Exception;
}