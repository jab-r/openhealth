package org.openhealth.saxon;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;

//import com.icl.saxon.*;
//import com.icl.saxon.output.*;
//import com.icl.saxon.expr.*;
import org.xml.sax.*;
import org.xml.sax.helpers.*;

import com.megginson.sax.XMLWriter;

import javax.xml.transform.*;
import javax.xml.transform.sax.*;
import javax.xml.transform.dom.*;
import javax.xml.transform.stream.*;

import org.openhealth.sax.*;


public class RepositoryFileHandler implements org.openhealth.saxon.SourceHandler {
		OutputStream os;
		XMLWriter wr;
	public void init(ServletConfig config) throws ServletException
	{
	};
	public XMLWriter getXMLWriter(org.openhealth.saxon.AbstractSaxonServlet servlet,String txnID,String txnState,String loc,String uid,HttpServletRequest req,HttpServletResponse res) 
		throws SAXException,IOException,FileNotFoundException
	{
		 os = new FileOutputStream(servlet.getRepositoryFile(req,loc,uid));
		 wr = new XMLWriter(new PrintWriter(os));
		return wr;
	};
	public void reset(HttpServletRequest req, HttpServletResponse res) throws Exception {
		try{
			wr.flush();
			os.close();
		} catch(IOException e) {};
		wr = null;
		os = null;
	};
};