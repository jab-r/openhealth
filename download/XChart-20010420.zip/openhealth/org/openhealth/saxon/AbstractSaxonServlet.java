package org.openhealth.saxon; 
/*
 * <p>Copyright (c) 2000-2001 The Open Healthcare Group</p>
 * <p>Licensed for distribution and/or use according to the Open Health Community License
 * see <a href="http://www.openhealth.org/license/">http://www.openhealth.org/license/</a>
 * <br />
 * <i>This software comes with NO WARRANTY or guarantee of fitness for any purpose.</i></p>
 */

import java.text.SimpleDateFormat;
import java.util.Date;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;

/*import com.icl.saxon.*;
import com.icl.saxon.output.*;
import com.icl.saxon.expr.*;
 */
import org.xml.sax.*;

import org.xml.sax.helpers.*;
import javax.xml.transform.*;
import javax.xml.transform.sax.*;
import javax.xml.transform.stream.*;

import org.openhealth.sax.*;

/**
 * SaxonServlet. Transforms a supplied input document using a supplied stylesheet
 */

public abstract class AbstractSaxonServlet extends HttpServlet {
    
    /**
     * service() - accept request and produce response<BR>
     * URL parameters: <UL>
     * <li>source - URL of source document</li>
     * <li>style - URL of stylesheet</li>
     * <li>clear-stylesheet-cache - if set to yes, empties the cache before running.
     * </UL>
     * @param req The HTTP request
     * @param res The HTTP response
     */
    protected String srcDir = "";
    protected String repository;
    protected String m_elName;
    protected boolean trace=false;
    protected String result = "";
    public void init(ServletConfig config) throws ServletException
    {
        super.init(config);
        srcDir = config.getInitParameter("source");
        repository = config.getInitParameter("repository");
        m_elName = config.getInitParameter("request-element-name");
        if (repository == null)
            repository = "repository/";
        if (m_elName == null)
            m_elName = "FORM";
        result = config.getInitParameter("result");
    }
    public void service(HttpServletRequest req, HttpServletResponse res)
    throws ServletException, IOException
    {
        String source = req.getParameter("source");
        String style = req.getParameter("style");
        String clear = req.getParameter("clear-stylesheet-cache");
        String strace = req.getParameter("trace");
        
        if (clear!=null && clear.equals("yes")) {
            clearCache();
        }
        if (strace!=null && strace.equals("yes")) {
            trace=true;
        }
        
        try {
            apply(fixupPath(req,style), (source==null)? null : fixupPath(req,source), req,res);
            //           apply(fixupPath(req,style), fixupPath(req,source), params, res);
        } catch (SAXException err) {
            res.getOutputStream().println("Error applying stylesheet: " + err.getMessage());
        }
        
    }
    public String fixupPath(HttpServletRequest req,String source) {
                /*String sp = req.getServletPath();
                int loc = sp.lastIndexOf('/');
                return sp.substring(0,loc+1).concat(source);
                 */
        return srcDir+source;
    }
    /**
     * getServletInfo<br />
     * Required by Servlet interface
     */
    
    public String getServletInfo() {
        return "base Openhealth servlet using SAXON XSLT";
    }
    
    public abstract String getUID(HttpServletRequest req);
    public File getRepositoryFile(HttpServletRequest req,String loc,String uid)
    throws IOException
    {
        
        String outfileDir = fixupPath(req,repository +loc);
        File ofd = new File(outfileDir);
        ofd.mkdirs();
        String outFileName = uid + ".xml";//getServletContext().getRealPath("/opnoteData/" + request.getParameter("patientid") + ".xml");
        return new File(ofd,outFileName);
    }
    /**
     * Apply stylesheet to source document
     */
    
    public abstract void apply(String style, String source,
    HttpServletRequest req,
    HttpServletResponse res)
    throws SAXException, ServletException, java.io.IOException;
  /**
   * @param where SAX DocumentHandler where to fire events
   * @param request Provides access to all meaningful parameters to set
   * @see #process
   */
    public void injectRequestParams(String elName,ContentHandler where,HttpServletRequest request,HttpServletResponse res)
    throws ServletException,IOException
    {
        //XMLParserLiaison liaison = xslproc.getXMLProcessorLiaison();
        AttributesImpl atts = new AttributesImpl();
        
        Enumeration paramNames = request.getParameterNames();
        while (paramNames.hasMoreElements())
        {
            String paramName = (String) paramNames.nextElement();
            try
            {
                String[] paramVals = request.getParameterValues(paramName);
                if (paramVals != null)
                {
                    atts.addAttribute("",paramName,paramName,"CDATA",paramVals[0]);
                }
            }
            catch (Exception e)
            {
            }
        }
        try
        {
            String remAddr = request.getRemoteAddr();
            String remHost = request.getRemoteHost();
            String remUser = request.getRemoteUser();
            if (remAddr != null) atts.addAttribute("","RemoteAddr","RemoteAddr","CDATA",remAddr);
            if (remHost != null) atts.addAttribute("","RemoteHost","RemoteHost","CDATA",remHost);
            if (remUser != null) atts.addAttribute("","RemoteUser","RemoteUser","CDATA",remUser);
            where.startElement("",elName,elName,(Attributes)atts);
            where.endElement("",elName,elName);
            
        }
        catch (Exception e)
        {
            e.printStackTrace(new PrintStream(res.getOutputStream()));
            throw new ServletException(e);
        }
        
    }
    
    /**
     * Maintain prepared stylesheets in memory for reuse
     */
    
    protected synchronized Templates tryCache(String url) throws SAXException,TransformerConfigurationException {
        /*String path = getServletContext().getRealPath(url);
        if (path==null) {
                        String p2 = getServletContext().getPathTranslated();
            throw new SAXException("Stylesheet " + url + " not found:"+p2);
        }*/
        Templates x = (Templates)cache.get(url);//path);
        if (x==null) {
            TransformerFactory tfactory = TransformerFactory.newInstance();
        // Create a templates object, which is the processed, 
        // thread-safe representation of the stylesheet.
            x = tfactory.newTemplates(new StreamSource(url));
            cache.put(url/*path*/, x);
        }
        return x;
    }
    
    /**
     * Clear the cache. Useful if stylesheets have been modified, or simply if space is
     * running low. We let the garbage collector do the work.
     */
    
    protected synchronized void clearCache() {
        cache = new Hashtable();
    }
    
    private Hashtable cache = new Hashtable();
}
