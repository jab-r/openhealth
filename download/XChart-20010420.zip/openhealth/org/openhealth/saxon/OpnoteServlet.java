package org.openhealth.saxon; 
/*
 * <p>Copyright (c) 2000-2001 The Open Healthcare Group</p>
 * <p>Licensed for distribution and/or use according to the Open Health Community License
 * see <a href="http://www.openhealth.org/license/">http://www.openhealth.org/license/</a>
 * <br />
 * <i>This software comes with NO WARRANTY or guarantee of fitness for any purpose.</i></p>
 */

import java.text.SimpleDateFormat;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;

import javax.xml.transform.*;
import javax.xml.transform.sax.*;
//import javax.xml.transform.dom.*;
import javax.xml.transform.stream.*;

import org.xml.sax.*;
import org.xml.sax.helpers.*;

import com.megginson.sax.XMLWriter;

import org.openhealth.sax.*;
import org.openhealth.saxon.*;
/** 
 * <p><i>OpnoteServlet</i> Transforms a supplied input document using a supplied stylesheet.</p>
 * <p>Configured as a SAX chain. XMLWriter used to save snapshot of current state.
 * HTTP Request params are injected as attributes of a &lt;form&gt; element and XSLT'd
 * into ASTM E31.25 format. The result of this is XSLT'd into XHTML for display.</p>
 * @author Jonathan Borden <jonathan@openhealth.org>
 */

public class OpnoteServlet extends org.openhealth.saxon.AbstractSaxonServlet {
    SourceHandler formHandler;
    SourceHandler resultHandler;
    ResponseHandler redirectHandler = null;
    private static final boolean debug = true;
    public void init(ServletConfig config) throws ServletException
    {
        super.init(config);
        try{
            String formCN = config.getInitParameter("request-handler");
            String resCN = config.getInitParameter("result-handler");
            String redirectCN = config.getInitParameter("response-handler");
            formHandler = (formCN==null) ? new RepositoryFileHandler() : (SourceHandler) Class.forName(formCN).newInstance();
            if (formHandler != null)
                formHandler.init(config);
            resultHandler = (resCN==null) ? new RepositoryFileHandler() : (SourceHandler) Class.forName(resCN).newInstance();
            if (resultHandler != null)
                resultHandler.init(config);
            redirectHandler = (redirectCN == null) ? null : (ResponseHandler) Class.forName(redirectCN).newInstance();
            if (redirectHandler != null)
                redirectHandler.init(config);
            
        } catch(Exception e) {
            throw new ServletException(e);
        };
    }
    
    /** getServletInfo<br />
     * Required by Servlet interface
     * @return Servlet information
     */
    
    public String getServletInfo() {
        return "Openhealth Opnote generator Servlet";
    }
    
/** <p>UIDs are created by combining <code>patientid</code> and timestamp information.</p>
 * @param req the servlet request
 * @return a string formed by the patient id + timestamp
 */
    public String getUID(HttpServletRequest req) {
        SimpleDateFormat formatter
        = new SimpleDateFormat(".yyyy.MM.dd.HH.mm.ss.SSSS");
        Date currentTime_1 = new Date();
        String dateString = formatter.format(currentTime_1);
        return req.getParameter("patientid") + dateString;
    }
    /** Apply stylesheet to source document
     * @param style XSLT Stylesheet
     * @param source XML Source document
     * @param params parameters to XSLT processor
     * @param req servlet request
     * @param res servlet response
     * @throws SAXException
     * @throws ServletException
     * @throws IOException
     */
    
    public void apply(  String style,
    String source,
    HttpServletRequest req,
    HttpServletResponse res)
    throws SAXException, ServletException, java.io.IOException {
        ServletOutputStream out = res.getOutputStream();
        
        if (style==null) {
            out.println("No style parameter supplied");
            return;
        }
        
        String sform = req.getParameter("form");
        boolean form = (sform == null) || (sform.equals("yes"));
        
        try {
            Templates templ1 = tryCache(style);
            Transformer trans1 = templ1.newTransformer();
            
            //trans1.setParams(params);
            Enumeration p = req.getParameterNames();
            while (p.hasMoreElements()) {
                String name = (String)p.nextElement();
                if (!(name.equals("style") || name.equals("source"))) {
                    String value = req.getParameter(name);
                    trans1.setParameter(name, value);
                }
            }         
            String theResult = result;
            String pResult = req.getParameter("result");
            if (pResult != null)
                theResult = pResult;
            Templates templ2 = tryCache(fixupPath(req,theResult));
            Transformer trans2 = templ2.newTransformer();
            javax.xml.transform.Result result;
            Properties details = templ2.getOutputProperties();
            res.setContentType(details.getProperty(OutputKeys.MEDIA_TYPE,"text/html"));
            
            ByteArrayOutputStream baos = null;
            if (redirectHandler == null) {
                result = new javax.xml.transform.stream.StreamResult(out);
                //details.setOutputStream (out);
            } else {
                baos = new ByteArrayOutputStream();
                result = new javax.xml.transform.stream.StreamResult(baos);
                //details.setOutputStream( baos );
            };
            //templ2.setOutputProperties(details);
            /*String path = getServletContext().getRealPath(source);
            if (path==null) {
                throw new SAXException("Source file " + source + " not found:"+path);
            }*/
  // start new
        TransformerFactory tfactory     = TransformerFactory.newInstance();

        // If one success, assume all will succeed.
        if (tfactory.getFeature(SAXSource.FEATURE)) {
            SAXTransformerFactory stf    = (SAXTransformerFactory) tfactory;
		// create XMLFilters from the XSLT
            TransformerHandler th1 = stf.newTransformerHandler(templ1);
            TransformerHandler th2 = stf.newTransformerHandler(templ2);
            String uid2 = getUID(req);
            if (null != th1)    // If one success, assume all were success.
            {
                // transformer1 will use a SAX parser as it's reader.    
                // below filter1.setContentHandler(chand2); ???//.setParent(reader);

// --
                if (source == null) {
                    //ContentHandler ch1 = filter1.getContentHandler();
                    //ContentHandler ch2 = filter2.getContentHandler();
                    String uid = getUID(req);
                    String txnID = req.getParameter("TXNID");
                    String txnState = req.getParameter("TXNSTATE");
                    if (txnState == null)
                        txnState = "CREATED";
					// This is usually an XMLWriter (save to file)	
                    XMLWriter wr1 = (form) ? formHandler.getXMLWriter(this,txnID,txnState,"opnoteData/",uid,req,res) : null;
                
                    //Serializer serResult = SerializerFactory.getSerializer(Method.XML);
                    trans1.setParameter("TXNID",uid2);
                    trans1.setParameter("TXNSTATE",txnState);
                    String loc = txnState+"/";
                    XMLWriter wr2 = resultHandler.getXMLWriter(this,txnID,txnState,loc,uid2,req,res);
                // transformer2 will use transformer1 as it's reader.
			//wr1.setParent(makeXMLReader());
			if (form) {
				wr1.setContentHandler((ContentHandler)th1);
			};
			th1.setResult(new SAXResult((ContentHandler)wr2));
			wr2.setContentHandler((ContentHandler)th2);
			th2.setResult(result);
			ContentHandler chwr1 = (wr1 == null) ? (ContentHandler) th1 : (ContentHandler) wr1;
			if (chwr1 == null)
				System.out.println("null ContentHandler for XMLWriter wr1");
			else {
				chwr1.startDocument();
				chwr1.processingInstruction("xsl-stylesheet","href='../../"+style+"' type='text/xsl'");
                		injectRequestParams(m_elName,chwr1,req,res);
				chwr1.endDocument();
                	};
                
            } else {
                //File sourceFile = new File(source/*path*/);
                trans2.transform(new StreamSource(source),result);
            };
            if (baos != null) {
                    baos.writeTo(out);
                    redirectHandler.handle(this,baos,req,res,uid2,"text/html");
                };
                //
                // transform3 will use transform2 as it's reader.
                //filter3.setParent(filter2);
                //filter3.setContentHandler(new ExampleContentHandler());

                // filter3.setContentHandler(new org.xml.sax.helpers.DefaultHandler());
                // Now, when you call transformer3 to parse, it will set  
                // itself as the ContentHandler for transform2, and 
                // call transform2.parse, which will set itself as the 
                // content handler for transform1, and call transform1.parse, 
                // which will set itself as the content listener for the 
                // SAX parser, and call parser.parse(new InputSource(foo_xml)).
                //filter3.parse(new InputSource(new File(sourceID).toURL().toString()));
            } else {
                System.out
                    .println("Can't do exampleXMLFilter because "
                             + "tfactory doesn't support newXMLFilter()");
            }
        } else {
            System.out.println("Can't do exampleXMLFilter because "
                               + "tfactory is not a SAXTransformerFactory");
        }
        } catch (SAXException err) {
            err.printStackTrace(new PrintStream(out));
            out.println(err.getMessage());
        } catch (Exception e) {
            e.printStackTrace(new PrintStream(out));
        } finally {
            try{
                if (form)
                    formHandler.reset(req,res);
            } catch (Exception ex) {
                ex.printStackTrace(new PrintStream(out));
            };
            try{
                resultHandler.reset(req,res);
            } catch (Exception ex) {
                ex.printStackTrace(new PrintStream(out));
            };
            
        };
    }
    /**
    * Make an XMLReader
    */
    
    private static XMLReader makeXMLReader() {
        return new com.icl.saxon.aelfred.SAXDriver();
    }

}
