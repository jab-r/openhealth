package org.openhealth.repository;

import java.util.Hashtable;
import java.io.File;
import java.io.OutputStream;
import org.apache.xml.serialize.XMLSerializer;
import org.apache.xml.serialize.DOMSerializer;
/**
 * Insert the type's description here.
 * Creation date: (7/10/00 11:02:03 PM)
 * @author: 
 */
public class Cache  {
	Hashtable hash = new Hashtable();
	static final String oh_nsBase = "http://www.openhealth.org/repository/";
	static final String rdf_nsSyntax = "http://www.w3.org/1999/02/22-rdf-syntax-ns#";
  
	org.openhealth.edit.DOMEditor editor = new org.openhealth.edit.DOMEditor();
	/**
	 * Constructor
	 * Creation date: (7/12/00 9:52:21 AM)
	 */
	public Cache() {
	}
	/**
	 * execute the edit commands in editDocument against
	 * the object specified by {type,UID}
	 */
	public org.w3c.dom.Document edit(String type, String uID, org.w3c.dom.Document editList) throws org.xml.sax.SAXException,java.io.IOException {
		org.w3c.dom.Document doc = get(type,uID);
		synchronized (doc) {
			if (true == editor.execute(editList,doc.getDocumentElement()))
				flush(type,uID,doc);
		};
		return doc;
	}
	protected void flush(String type,String uid,org.w3c.dom.Document doc) throws java.io.IOException {
	
		 File f = new File(getPath(type,uid));
		 XMLSerializer serializer = new XMLSerializer(new java.io.FileOutputStream(f),null);
		 DOMSerializer domser = serializer.asDOMSerializer();
		 domser.serialize(doc);

	}
	/**
	 * get method comment.
	 */
	public synchronized org.w3c.dom.Document get(String type, String uID) {
		String key = getPath(type,uID);
		org.w3c.dom.Document doc = (org.w3c.dom.Document) hash.get(key);
		if (null == doc) {
			String nsType = oh_nsBase + type;
			String nsInstance = nsType + "/" + uID;
			org.w3c.dom.DOMImplementation dom = new org.apache.xerces.dom.DOMImplementationImpl();
			doc = dom.createDocument(rdf_nsSyntax,"rdf:RDF",null);
			Element rdfRoot = doc.getDocumentElement();
			Element desc = doc.createElementNS(rdf_nsSyntax,"rdf:Description");
			desc.setAttribute("about",nsInstance);
			Element type = doc.createElementNS(rdf_nsSyntax,"rdf:type");
			type.setAttribute("resource",nsType);
			desc.appendChild(type);
			rdfRoot.appendChild(desc);
			Element res = doc.createElementNS(oh_nsBase,type);
			desc.appendChild(res);

			/*
				<rdf:RDF xmlns:rdf="..">
					<rdf:Description about="instance UID">
						<rdf:type resource="typeID"/>
						<oh:person>
							<name><first>John</first><last>Doe</last>
							</name>
			*/

			/* doc = new DocumentImpl();
			org.w3c.dom.Element el = doc.createElementNS(oh_nsBase+type,type);
			doc.appendChild(el);
			*/
			hash.put(key,doc);
		};
		return doc;
	}
	/**
	 * Insert the method's description here.
	 * Creation date: (7/12/00 9:08:31 AM)
	 * @return java.lang.String
	 * @param type java.lang.String
	 * @param uid java.lang.String
	 */
	public String getPath(String type, String uid) {
		return uid + "/" + type + ".xml";
	}
	public void reload(String type,String uid) {
		String key = getPath(type,uid);
		hash.remove(key);
		get(type,uid);
	}
}
