package org.openhealth.repository;

public class UIDGen {
	public static String UID() {
		String ret = (new java.rmi.server.UID()).toString() + ".";
		try{
			ret += java.net.InetAddress.getLocalHost().getHostAddress();
		} catch(Exception e) {
			ret += "unknown";
		};
		return ret;
	}
}
