package org.openhealth.repository;

	import org.w3c.dom.*;
/**
 * Insert the type's description here.
 * Creation date: (7/10/00 10:22:30 PM)
 * @author: 
 */
public interface Documents {
	
	public org.w3c.dom.Document edit(String type,String UID,org.w3c.dom.Document editList) ;
	void exec(String UID,Document doc,Document editList) ;
	public org.w3c.dom.Document get(String type,String UID) ;
}
