package org.openhealth.sax;

import com.icl.saxon.trace.*;

import org.xml.sax.SAXException;
import com.icl.saxon.style.StyleElement;
import com.icl.saxon.handlers.NodeHandler;
import com.icl.saxon.*;
import com.icl.saxon.om.NodeInfo;
import com.icl.saxon.om.ElementInfo;

import java.io.*;
/**
* A Simple trace listener that writes messages to System.err
*/

public class StreamTraceListener implements TraceListener {

  String indent = "";

  PrintStream out;
  public StreamTraceListener(OutputStream os){
	  out = new PrintStream(os);
  };
  /**
  * Called at start
  */

  public void open() {
    out.println("<trace>");out.flush();
  }

  /**
  * Called at end
  */

  public void close() {
    out.println("</trace>");out.flush();
  }
  
  

  /**
   * Called for all top level elements
   */
  public void toplevel(NodeInfo element)
    throws SAXException
  {
    StyleElement e = (StyleElement)element;
    out.println("<Top-level element=\"" + e.getDisplayName() + "\" line=\"" + e.getLineNumber() +
       "\" file=\"" + e.getSystemId() + "\" precedence=\"" + e.getPrecedence() +"\"/>");
	out.flush();
  }

  /**
   * Called when a node of the source tree gets processed
   */
  public void enterSource(NodeHandler handler, Context context)
    throws SAXException
  {
    NodeInfo curr = context.getContextNode();
    out.println(indent + "<Source node=\""  + curr.getPath()
                        + "\" line=\"" + curr.getLineNumber()
		                + "\" mode=\"" + getModeName(context) + "\">");
	out.flush();
    indent += " ";
  }

  /**
   * Called after a node of the source tree got processed
   */
  public void leaveSource(NodeHandler handler, Context context)
    throws SAXException
  {
    indent = indent.substring(0, indent.length() - 1);
    out.println(indent + "</Source><!-- "  + context.getContextNode().getPath() + " -->");out.flush();
  }

  /**
   * Called when an element of the stylesheet gets processed
   */
  public void enter(NodeInfo element, Context context)
    throws SAXException
  {
    if (element instanceof ElementInfo) {
        out.println(indent + "<Instruction element=\"" + element.getDisplayName() + "\" line=\"" + element.getLineNumber() + "\">");
		out.flush();
        indent += " ";
    }
  }

  /**
   * Called after an element of the stylesheet got processed
   */
  public void leave(NodeInfo element, Context context)
    throws SAXException
  {
    if (element instanceof ElementInfo) {
        indent = indent.substring(0, indent.length() - 1);
        out.println(indent + "</Instruction> <!-- " + element.getDisplayName() + " -->");
		out.flush();
    }
  }

  String getModeName(Context context)
  {
    String name = context.getMode().getName();
    return (name==null ? "*default*" : name);
  }
}
