package org.openhealth.sax;

import com.icl.saxon.AttributeCollection;
import com.icl.saxon.om.Name;
import com.icl.saxon.output.Emitter;
import com.icl.saxon.output.XMLEmitter;
import org.xml.sax.*;
import org.xml.sax.helpers.*;

public class EmitterFilter extends DefaultHandler {
	protected XMLEmitter emitter;
	public EmitterFilter(XMLEmitter emit) {
		emitter = emit;
	};
	public Emitter getEmitter(){
		return emitter;
	};
    public void startDocument ()
	throws SAXException
    {
		emitter.startDocument();
    }
    public void endDocument ()
	throws SAXException
    {
		emitter.endDocument();
    }

    public void startElement (String uri, String localName,
			      String qName, Attributes attributes)
	throws SAXException
    {
		int n = attributes.getLength();
		AttributeCollection atts = new AttributeCollection(attributes.getLength());
		for(int i = 0;i<n;i++) {
			atts.addAttribute(rawNameToPrefix(attributes.getQName(i)),
							attributes.getURI(i),
							attributes.getLocalName(i),
							attributes.getType(i),
							attributes.getValue(i));
		};
		emitter.startElement(new Name(rawNameToPrefix(qName),uri,localName),atts);
    }
    public void endElement (String uri, String localName, String qName)
	throws SAXException
    {
		emitter.endElement(new Name(rawNameToPrefix(qName),uri,localName));
    }
    public void startPrefixMapping (String prefix, String uri)
	throws SAXException
    {
		emitter.startPrefixMapping(prefix,uri);
    }

    public void characters (char ch[], int start, int length)
	throws SAXException
    {
		emitter.characters(ch,start,length);
    }
    
    public void processingInstruction (String target, String data)
	throws SAXException
    {
		emitter.processingInstruction(target,data);
    }
    public void comment (char ch[], int start, int length) throws SAXException
    {
		emitter.comment(ch,start,length);
	};
    /**
    * Extract the prefix from a QName
    * @return the prefix as an interned string
    */

    private String rawNameToPrefix(String rawname) {
        int colon = rawname.indexOf(':');
        if (colon<0) {
            return "";
        } else {
            return rawname.substring(0, colon).intern();
        }
    }

};