package org.openhealth.sax;

import org.xml.sax.*;
/**
 * Like ForkImpl but hooks startDocument to insert an xml-stylesheet PI
 */
public class ForkImplStyle extends ForkImpl {
	String m_xslName;
	public ForkImplStyle(String xslSheet,DocumentHandler left,DocumentHandler right) {
		super(left,right);
		m_xslName = xslSheet;

	}
	/**
	 * Receive notification of the beginning of a document.
	 *
	 * <p>The SAX parser will invoke this method only once, before any
	 * other methods in this interface or in DTDHandler (except for
	 * setDocumentLocator).</p>
	 *
	 * @exception org.xml.sax.SAXException Any SAX exception, possibly
	 *            wrapping another exception.
	 */
	public void startDocument ()
		throws SAXException {
			String pidata = "type=\"text/xsl\" href=\""+m_xslName+"\"";
			super.startDocument();
			super.processingInstruction("xml-stylesheet",pidata);
	}
}
