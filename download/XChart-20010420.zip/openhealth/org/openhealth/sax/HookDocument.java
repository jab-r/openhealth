package org.openhealth.sax;

import org.xml.sax.DocumentHandler;
/**
 * Insert the type's description here.
 * Creation date: (7/30/00 11:56:48 AM)
 * @author: 
 */
public class HookDocument implements org.xml.sax.DocumentHandler {
	String m_xslHref;
	DocumentHandler m_hand;
	public HookDocument(DocumentHandler hand,String xslSheet) {
		m_xslHref = xslSheet;
		m_hand = hand;
	}
/**
 * characters method comment.
 */
public void characters(char[] ch, int start, int length) throws org.xml.sax.SAXException {
	m_hand.characters(ch,start,length);}
/**
 * endDocument method comment.
 */
public void endDocument() throws org.xml.sax.SAXException { m_hand.endDocument();}
/**
 * endElement method comment.
 */
public void endElement(String name) throws org.xml.sax.SAXException {
	m_hand.endElement(name);}
/**
 * ignorableWhitespace method comment.
 */
public void ignorableWhitespace(char[] ch, int start, int length) throws org.xml.sax.SAXException {
	m_hand.ignorableWhitespace(ch,start,length);}
/**
 * processingInstruction method comment.
 */
public void processingInstruction(String target, String data) throws org.xml.sax.SAXException {
	m_hand.processingInstruction(target,data);}
/**
 * setDocumentLocator method comment.
 */
public void setDocumentLocator(org.xml.sax.Locator locator) {
	m_hand.setDocumentLocator(locator);}
	public void startDocument() throws org.xml.sax.SAXException {
		m_hand.startDocument();
		m_hand.processingInstruction("xml-stylesheet","type='text/xsl' href='"+m_xslHref+"'");
	}
/**
 * startElement method comment.
 */
public void startElement(String name, org.xml.sax.AttributeList atts) throws org.xml.sax.SAXException {
	m_hand.startElement(name,atts);
	}
}
